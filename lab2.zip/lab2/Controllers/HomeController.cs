﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Lab2.Controllers
{
    public class HomeController : Controller
    {
        /// <summary>
        /// GET: Home/Acceuil
        /// Le controller de la page d'acceuil
        /// </summary>
        /// <returns>Acceuil</returns>
        public ActionResult Acceuil()
        {
            return View("Acceuil");
        }
    }
}