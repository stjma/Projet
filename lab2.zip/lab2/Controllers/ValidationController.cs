﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;


namespace Lab2.Controllers
{
    public class ValidationController : Controller
    {
        /// <summary>
        /// Validation du champ Adresse
        /// </summary>
        /// <param name="Adresse"></param>
        /// <returns></returns>
        public JsonResult ValiderAdresse(string Adresse)
        {         
            bool reponce;
            // retourne true si Adresse contient que ces chiffre sans espace
            if(Regex.IsMatch(Adresse, @"^[\d]+$")){ reponce = true; }
            // retourne false si Adresse contient des caracteres autres que des chiffres
            else { reponce = false; }

            return Json(reponce, JsonRequestBehavior.AllowGet);
        }
    }
}
//Pour le debogage en console
//System.Diagnostics.Debug.WriteLine(Valeur_a_afficher);