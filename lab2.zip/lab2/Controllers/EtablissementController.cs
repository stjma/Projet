﻿using Lab2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Lab2.Controllers
{
    public class EtablissementController : Controller
    {

        /// <summary>
        /// GET: Etablissement/AjouterEtudiant
        /// </summary>
        /// <returns></returns>
        public ActionResult AjouterEtudiant()
        {
            return View();
        }


        /// <summary>
        /// POST: Etablissement/AjouterEtudiant/5
        /// Ajout avec un Etudiant
        /// </summary>
        /// <param name="etudiant"></param>
        /// <returns>ListeEtudiants</returns>
        [HttpPost]
        public ActionResult AjouterEtudiant(Etudiant etudiant)
        {
            Etablissement.Ajouter(etudiant);
            return RedirectToAction("ListeEtudiants");
        }

        /// <summary>
        /// GET: Etablissement/SupprimerEtudiant
        /// suppression avec le numero Etudiant
        /// </summary>
        /// <param name="numeroEtudiant"></param>
        /// <returns>ListeEtudiants</returns>
        public ActionResult SupprimerEtudiant(int numeroEtudiant)
        {
            Etablissement.Supprimer(Etablissement.GetEtudiant(numeroEtudiant));
            return RedirectToAction("ListeEtudiants");
        }

        /// <summary>
        /// GET: Etablissement/ListeEtudiants
        /// </summary>
        /// <returns>Liste Etudiant</returns>
        public ActionResult ListeEtudiants()
        {
            //Retourne la liste d'etudiant
            return View(Etablissement.GetListeEtudiant());
        }
    }
}