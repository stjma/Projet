﻿using Lab2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Lab2.Controllers
{
    public class EtudiantController : Controller
    {

        /// <summary>
        /// GET: Etudiant/ListeNotes/5
        /// </summary>
        /// <param name="etudiant"></param>
        /// <returns>Liste des Notes</returns>
        public ActionResult ListeNotes(int etudiant)
        {
            Etudiant etu = Etablissement.GetEtudiant(etudiant);
            
            return View(etu.GetNotes());
        }

        /// <summary>
        /// GET: Etudiant/AjouterNote/5
        /// </summary>
        /// <param name="etudiant"></param>
        /// <returns></returns>
        public ActionResult AjouterNote(int etudiant)
        {         
            return View();
        }

        /// <summary>
        /// POST: Etudiant/AjouterNote
        /// Ajout d'une note a l'aide du numero de l'etudiant et de sa note
        /// </summary>
        /// <param name="etudiant"></param>
        /// <param name="note"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult AjouterNote(int etudiant, Note note)
        {
            try
            {             
                Etudiant etu = Etablissement.GetEtudiant(etudiant);
                //Ajout de la note
                etu.Ajouter(note);
                
                //Redirection vers ListeNotes avec un numero etudiant pour afficher les notes dans ListeNotes
                return RedirectToAction("ListeNotes", new { etudiant = etudiant });
            }
            catch
            {
                //Si il y a une erreur AjouterNote retourne une view vide
                return View();
            }
        }

        /// <summary>
        /// GET: Etudiant/SupprimerNote/5
        /// Suppresion d'une note avec le numero etudiant et le numero du cours
        /// </summary>
        /// <param name="etudiant"></param>
        /// <param name="cours"></param>
        /// <returns>ListeNotes et Etudiant</returns>
        public ActionResult SupprimerNote(int etudiant,int cours)
        {
            //recherche d'un etudiant
            Etudiant etu = Etablissement.GetEtudiant(etudiant);

            //suppression d'une note avec l'etudiant
            etu.Supprimer(cours);

            //Redirection vers ListeNotes avec un numero etudiant pour afficher les notes dans ListeNotes
            return RedirectToAction("ListeNotes", new { etudiant = etudiant });
        }

        /// <summary>
        /// GET: Etudiant/Bulletin/5
        /// recherche d'une etudiant pour l'afficher
        /// </summary>
        /// <param name="etudiant"></param>
        /// <returns>etu</returns>
        public ActionResult Bulletin(int etudiant = -1)
        {
            if(etudiant >= 0)
            {
                Etudiant etu = Etablissement.GetEtudiant(etudiant);
                if(etu != null)
                {
                    //Afficher les informations d'un etudiants
                    ViewBag.nom = etu.Nom;
                    ViewBag.prenom = etu.Prenom;
                    ViewBag.tel = etu.Telephone;
                    ViewBag.adrese = etu.Adresse;

                    return View(etu.GetNotes());
                }
                else
                {
                    return View();
                }
               
            }
            else
            {
                return View();
            }
            
        }
    }
}