﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Lab2.Models
{
    public class Etudiant
    {
        /// <summary>
        /// le numero de l'etudiant
        /// champ requis
        /// </summary>
        [Required]
        public int NumEtudiant { get; set; }

        /// <summary>
        /// le nom de l'etudiant
        /// champ requis
        /// validation Majuscule suivi de minuscule
        /// </summary>
        [Required]
        [RegularExpression(pattern: @"^[A-Z][\w]{1,29}$", ErrorMessage = "Vous devez ecrire (Une lettre majuscule suivi de maximum 29 lettres)")]
        public string Nom { get; set; }

        /// <summary>
        /// prenom de l'etudiant
        /// champ requis
        /// validation Majuscule suivi de minuscule
        /// </summary>
        [Required]
        [RegularExpression(pattern: @"^[A-Z][\w]{1,29}$", ErrorMessage = "Vous devez ecrire (Une lettre majuscule suivi de maximum 29 lettres)")]
        public string Prenom { get; set; }

        /// <summary>
        /// le telephone de l'etudiant avec la valisation (Code regional) 
        /// premiere partie numero-deuxieme partie numeo
        /// (123) 123-4567
        /// champ requis
        /// </summary>
        [Required]
        [RegularExpression(pattern: @"^\([1-9][\d]{2}\) [\d]{3}-[\d]{4}$", ErrorMessage = "telephone n'est pas valide")]
        public string Telephone { get; set; }

        /// <summary>
        /// Adresse de l'etudiant
        /// validation fait dans le controleur Validation
        /// doit etre que des chiffre sans espace
        /// champ requis
        /// </summary>
        [Required]
        [System.Web.Mvc.Remote(action: "ValiderAdresse", controller: "Validation", ErrorMessage = "Adresse pas valide")]
        public string Adresse { get; set; }

        /// <summary>
        /// le courriel de l'etudiant
        /// validation du courriel 
        /// doit commencer par 
        /// -un letre 
        /// -suivi de moin de 50 carracteres 
        /// -suivi d'un @ 
        /// -suivi de lettre au nombre de 1 a 10 carractere 
        /// -suivi de .com ou .ca
        /// exemple
        /// -Etablissement123@note.com
        /// -Etablissement123@note.ca
        /// champ requis
        /// </summary>
        [Required]
        [RegularExpression(pattern: @"^[\w][\w|\d]{1,50}@[\w]{1,10}(.com|.ca)$", ErrorMessage = "Numero pas valide")]
        public string Courriel { get; set; }

        /// <summary>
        /// liste des notes
        /// </summary>
        
        public SortedList<int, Note> ListeNotes = new SortedList<int, Note>();

        /// <summary>
        /// Ajout d'une notes a l'aide d'une note
        /// </summary>
        /// <param name="note"></param>
        public void Ajouter(Note note)
        {
            ListeNotes.Add(note.NumCours, note);
        }

        /// <summary>
        /// suppresion d'un note a l'aide du numero cours
        /// </summary>
        /// <param name="numeroCours"></param>
        public void Supprimer(int numeroCours)
        {
            ListeNotes.Remove(numeroCours);
        }

        /// <summary>
        /// la liste des notes sans le cle int de la sortedlist
        /// </summary>
        /// <returns>liste</returns>
        public List<Note> GetNotes()
        {
            List<Note> liste = new List<Note>();
            //recherche parmis tous les Sortedliste et ajout dans un list
            foreach (var note in ListeNotes) { liste.Add(note.Value); }
            return liste;
        }

    }
}