﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Lab2.Models
{
    public class Note
    {
        /// <summary>
        /// le numero du cours
        /// </summary>
        [Required]
        public int NumCours { get; set; }

        /// <summary>
        /// le nom du cours
        /// </summary>
        [Required]
        public string NomCours { get; set; }

        /// <summary>
        /// la note du cours
        /// doit etre entre 0 et 199
        /// </summary>
        [Required]
        [Range(minimum:0,maximum:100,ErrorMessage ="Le nombre doit etre entre 0 et 100")]
        public int Notes { get; set; }

        /// <summary>
        /// la session durant laquel le cours a ete fait
        /// doit etre automne, ete ou hiver
        /// </summary>
        [Required]
        [RegularExpression(pattern:"^(automne)|(hiver)|(ete)$",ErrorMessage ="Vous devez ecrire (automne, hiver  ou ete)")]
        public string Session { get; set; }

        /// <summary>
        /// Quel annee le cours a ete complete
        /// </summary>
        [Required]
        public int Annee { get; set; }
    }
}