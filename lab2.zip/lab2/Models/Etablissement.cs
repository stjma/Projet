﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lab2.Models
{
    public static class Etablissement
    {
        /// <summary>
        /// Liste des Etudiants
        /// </summary>
        private static List<Etudiant> listeEtudiants = new List<Etudiant>();

        /// <summary>
        /// Le nom de l'etablissement
        /// </summary>
        public static string Nom { get; set; }

        /// <summary>
        /// l'Adresse de l'etablissement
        /// </summary>
        public static string Adresse { get; set; }

        /// <summary>
        /// Le telephone de l'etablissement
        /// </summary>
        public static string Telephone { get; set; }

        /// <summary>
        /// ajouter un etudiant a la liste des etudiants
        /// </summary>
        /// <param name="etudiant"></param>
        public static void Ajouter(Etudiant etudiant)
        {
            listeEtudiants.Add(etudiant);
        }

        /// <summary>
        /// supprimer un etudiant a la liste des etudiant
        /// </summary>
        /// <param name="etudiant"></param>
        public static void Supprimer(Etudiant etudiant)
        { 
            listeEtudiants.Remove(etudiant);
        }

        /// <summary>
        /// Retourner la liste des etudiants
        /// </summary>
        /// <returns>listeEtudiants</returns>
        public static List<Etudiant> GetListeEtudiant()
        {
            return listeEtudiants;
        }

        /// <summary>
        /// REtourner un etudiant par son numero etudiant
        /// </summary>
        /// <param name="numeroEtudiant"></param>
        /// <returns>Etudiant</returns>
        public static Etudiant GetEtudiant(int numeroEtudiant)
        {
            return listeEtudiants.Find(Etudiant => Etudiant.NumEtudiant == numeroEtudiant);
        }
    }
}